import{o as e,i as o}from"./.pnpm.55d2c8ea.js";import{d as r}from"./index.b53a8513.js";const c={};function n(t,s){return e(),o("div",null," 重定向页面 ")}const f=r(c,[["render",n]]);export{f as default};
